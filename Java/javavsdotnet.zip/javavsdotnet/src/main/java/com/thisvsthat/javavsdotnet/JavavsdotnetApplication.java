package com.thisvsthat.javavsdotnet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavavsdotnetApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavavsdotnetApplication.class, args);
	}

}
