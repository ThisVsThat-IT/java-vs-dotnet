package com.thisvsthat.javavsdotnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavavsdotnetApplicationTests {

	@Test
	void contextLoads() {
	}

}
